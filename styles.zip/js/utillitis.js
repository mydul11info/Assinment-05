

function getInputFieldValueById(id){
    const input = document.getElementById(id).value;
    const inputNumbaral = parseFloat(input);
    return inputNumbaral ;
}


function getTextFieldValueById(id){
    const textValue = document.getElementById(id).innerText;
    const textNumbaral = parseFloat(textValue);
    return textNumbaral;
}




