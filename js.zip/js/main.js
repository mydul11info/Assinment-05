document.getElementById('noakhali-donate')
.addEventListener('click', function (event) {
    event.preventDefault();


    const addMoney = getInputFieldValueById('noakhali-input');
    console.log('add money with parameter', addMoney)




    const balance = getTextFieldValueById('noakhali-amound');
    const totalBalance = getTextFieldValueById('total-amound');
     if(isNumber = Number && totalNewbalance < balance ){
    
    
    const newbalance = balance + addMoney;
    console.log(balance)

    document.getElementById('noakhali-amound').innerText = newbalance

    
    const totalNewbalance = totalBalance - newbalance;
    console.log(totalBalance)

    document.getElementById('total-amound').innerText = totalNewbalance


   }  


});







     

